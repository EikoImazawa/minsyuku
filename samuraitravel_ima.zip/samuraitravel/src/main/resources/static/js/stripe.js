const stripe = Stripe('pk_test_51OcQLsAtOFVqdH4WIPhZtYgduIEKIA2lnnlWP7GvB7AwPdEXAL50XJVo86dhESBTtPxvON365tyOnq6Rub30ZBAY00GwYJYOHA');
 const paymentButton = document.querySelector('#paymentButton');
 
 paymentButton.addEventListener('click', () => {
   stripe.redirectToCheckout({
     sessionId: sessionId
   })
 });